/*
 * mainCode.cpp
 *
 *  Created on: Sep 30, 2019
 *      Author: Debra
 */

#include "Coder.hpp"
#include <iostream>
#include <stdlib.h>
using namespace std;

int main() {
	Coder code;

}


